package com.example.hitung_bangun_20030008;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private CheckBox cbLingkaran, cbBola;
    private EditText etJari;
    private Button btnHitung;
    private TextView tvHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbLingkaran = findViewById(R.id.cb_lingkaran);
        cbBola = findViewById(R.id.cb_bola);
        etJari = findViewById(R.id.et_jari);
        btnHitung = findViewById(R.id.btn_hitung);
        tvHasil = findViewById(R.id.tv_hasil);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbLingkaran.isChecked()) {
                    double jari = Double.parseDouble(etJari.getText().toString());
                    double luas = Math.PI * jari * jari;
                    double keliling = 2 * Math.PI * jari;
                    tvHasil.setText("Luas: " + luas + "\nKeliling: " + keliling);
                } else if (cbBola.isChecked()) {
                    double jari = Double.parseDouble(etJari.getText().toString());
                    double volume = (4.0 / 3.0) * Math.PI * jari * jari * jari;
                    double keliling = 4 * Math.PI * jari * jari;
                    tvHasil.setText("Volume: " + volume + "\nKeliling: " + keliling);
                }
            }
        });
    }
    }
